"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import Nav         from "@/components/Nav";
import ProductCard from "@/components/ProductCard";
import { useCart } from "@/lib/CartContext";
import useWishlist from "@/lib/useWishlist";
import { FALLBACK_PRODUCTS, suggestBundles } from "@/lib/products";

const WA_PHONE = "18763405862";

export default function ProductPage() {
  const { id }     = useParams();
  const { addToCart } = useCart();
  const { toggle, isWished } = useWishlist();
  const [product,  setProduct]  = useState(null);
  const [bundles,  setBundles]  = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [added,    setAdded]    = useState(false);

  useEffect(() => {
    if (!id) return;
    fetch(`/api/products/${id}`)
      .then(r => r.json())
      .then(async p => {
        if (p.error) throw new Error(p.error);
        setProduct(p);
        const all = await fetch("/api/products").then(r => r.json()).catch(() => FALLBACK_PRODUCTS);
        if (Array.isArray(all)) setBundles(suggestBundles(p, all));
      })
      .catch(() => {
        const fb = FALLBACK_PRODUCTS.find(fp => String(fp.id) === String(id)) || FALLBACK_PRODUCTS[0];
        setProduct(fb);
      })
      .finally(() => setLoading(false));
  }, [id]);

  const handleAddToCart = () => {
    if (!product) return;
    addToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  if (loading) return (
    <><Nav /><main className="page">
      <div style={{ display:"flex", flexDirection:"column", gap:"1rem" }}>
        <div className="product-skeleton-img" style={{ borderRadius:"var(--radius)", aspectRatio:"1" }} />
        {[40,80,30,60].map((w,i) => <div key={i} className="product-skeleton-line" style={{ width:`${w}%`, height: i===1?28:14 }} />)}
      </div>
    </main></>
  );

  if (!product) return (
    <><Nav /><main className="page"><div className="empty"><p>Product not found</p><Link href="/" className="btn btn-pink" style={{ marginTop:"1rem", display:"inline-flex" }}>Back to Shop</Link></div></main></>
  );

  const isInStock    = product.in_stock ?? true;
  const hasPrice     = product.price && Number(product.price) > 0;
  const displayPrice = hasPrice ? `$${Number(product.price).toLocaleString()} JMD` : "Price coming soon";
  const waUrl        = `https://wa.me/${WA_PHONE}?text=${encodeURIComponent(`Hi, I want to order ${product.name} - Code: ${product.product_code}`)}`;

  return (
    <><Nav />
    <main className="page" style={{ paddingBottom:"6rem" }}>
      <div className="breadcrumb">
        <Link href="/">Shop</Link><span>›</span>
        <span>{product.category}</span><span>›</span>
        <span style={{ color:"var(--text)", fontWeight:700 }}>{product.name}</span>
      </div>
      <div className="detail-grid">
        <div style={{ position:"relative" }}>
          <div className="detail-img">
            <img src={product.image_path || "/placeholder.png"} alt={product.name} onError={e => { e.target.src="/placeholder.png"; }} />
          </div>
          <button onClick={() => toggle(product.id)} aria-label="Wishlist"
            style={{ position:"absolute", top:12, right:12, background:"rgba(255,255,255,.92)", border:"none", borderRadius:"50%", width:40, height:40, fontSize:"1.2rem", display:"flex", alignItems:"center", justifyContent:"center", cursor:"pointer", boxShadow:"0 2px 10px rgba(0,0,0,.12)" }}>
            {isWished(product.id) ? "❤️" : "🤍"}
          </button>
        </div>
        <div className="detail-info">
          <span className="detail-cat">{product.category}</span>
          <h1 className="detail-name">{product.name}</h1>
          <span className="detail-code">Code: {product.product_code}</span>
          {product.description && <p style={{ fontSize:".95rem", color:"#4b5563", lineHeight:1.7 }}>{product.description}</p>}
          <div className="detail-price">{displayPrice}</div>
          {!isInStock && <div style={{ padding:".75rem 1rem", background:"#fee2e2", borderRadius:10, fontWeight:700, color:"#991b1b" }}>⚠️ Currently out of stock</div>}
          {isInStock && hasPrice && (
            <div className="detail-actions">
              <button onClick={handleAddToCart} className="btn btn-pink" style={{ flex:1, padding:".9rem", fontSize:"1rem" }}>
                {added ? "✅ Added!" : "🛒 Add to Cart"}
              </button>
              <a href={waUrl} target="_blank" rel="noopener noreferrer" className="btn btn-wa" style={{ flex:1, padding:".9rem", fontSize:"1rem" }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                WhatsApp
              </a>
            </div>
          )}
          <Link href="/" className="btn btn-outline" style={{ textAlign:"center" }}>← Continue Shopping</Link>
        </div>
      </div>
      {bundles.length > 0 && (
        <div className="bundle-section">
          <h2>🎁 Bundle it with <span>these picks</span></h2>
          <div className="bundle-grid">
            {bundles.map(b => <ProductCard key={b.id} product={b} onAddToCart={addToCart} onWishlist={toggle} isWished={isWished(b.id)} />)}
          </div>
        </div>
      )}
    </main></>
  );
}
