"use client";
import { useState, useRef, useCallback } from "react";
const CATEGORIES = ["Baby Carriers","Accessories","Toys & Bouncers"];

function UploadZone({ onProductAdded }) {
  const [dragging, setDragging] = useState(false);
  const [uploads,  setUploads]  = useState([]);
  const inputRef = useRef();

  const processFile = useCallback(async (file) => {
    const uid = `${Date.now()}-${Math.random()}`;
    setUploads(u => [...u, { uid, name: file.name, preview: URL.createObjectURL(file), status: "uploading" }]);
    const form = new FormData();
    form.append("file", file);
    try {
      const res  = await fetch("/api/images", { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Upload failed");
      setUploads(u => u.map(i => i.uid === uid ? { ...i, status: "done", product: data.product, source: data.source, compression: data.compression } : i));
      onProductAdded(data.product);
    } catch (err) {
      setUploads(u => u.map(i => i.uid === uid ? { ...i, status: "error", error: err.message } : i));
    }
  }, [onProductAdded]);

  const handleFiles = (files) => Array.from(files).filter(f => f.type.startsWith("image/")).forEach(processFile);

  return (
    <div>
      <div onClick={() => inputRef.current.click()}
        onDragOver={e => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={e => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files); }}
        style={{ border: `2px dashed ${dragging ? "#ff6b9d" : "#e5e7eb"}`, borderRadius: 16, padding: "2.5rem 1.5rem", textAlign: "center", cursor: "pointer", background: dragging ? "#fff0f6" : "#fafafa", transition: "all .2s" }}>
        <div style={{ fontSize: "2.5rem", marginBottom: 8 }}>🤖📸</div>
        <p style={{ fontWeight: 800, fontSize: "1rem", marginBottom: 4 }}>Drop product images here</p>
        <p style={{ fontSize: ".82rem", color: "#9ca3af" }}>Claude AI reads the image → auto-fills name, price, code & category. Images are compressed to WebP automatically.</p>
        <input ref={inputRef} type="file" multiple accept="image/*" style={{ display:"none" }} onChange={e => handleFiles(e.target.files)} />
      </div>
      {uploads.length > 0 && (
        <div style={{ marginTop: "1rem", display: "flex", flexDirection: "column", gap: ".6rem" }}>
          {uploads.map(u => (
            <div key={u.uid} style={{ display: "flex", alignItems: "center", gap: ".75rem", padding: ".65rem .85rem", borderRadius: 10, background: u.status==="error"?"#fef2f2":u.status==="done"?"#f0fdf4":"#fefce8", border: `1px solid ${u.status==="error"?"#fecaca":u.status==="done"?"#bbf7d0":"#fde68a"}` }}>
              <img src={u.preview} alt="" width={44} height={44} style={{ borderRadius: 6, objectFit:"cover", flexShrink:0 }} />
              <div style={{ flex:1, minWidth:0 }}>
                <p style={{ fontSize:".82rem", fontWeight:700, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{u.name}</p>
                {u.status==="uploading" && <p style={{ fontSize:".75rem", color:"#d97706" }}>🔍 Compressing + analysing…</p>}
                {u.status==="done" && u.product && (
                  <p style={{ fontSize:".75rem", color:"#059669" }}>
                    ✅ <strong>{u.product.name}</strong> · ${u.product.price} · #{u.product.product_code}
                    {u.compression && <span style={{ marginLeft:8, opacity:.65 }}>📦 {u.compression.saving} smaller</span>}
                    <span style={{ marginLeft:6, opacity:.55 }}>via {u.source}</span>
                  </p>
                )}
                {u.status==="error" && <p style={{ fontSize:".75rem", color:"#dc2626" }}>❌ {u.error}</p>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function AdminClient({ initialProducts }) {
  const [products, setProducts] = useState(initialProducts);
  const [flash,    setFlash]    = useState(null);
  const [saving,   setSaving]   = useState({});
  const fileRef = useRef();

  const showFlash = (msg, type="success") => { setFlash({ msg, type }); setTimeout(() => setFlash(null), 4000); };

  const handleProductAdded = useCallback((product) => {
    if (!product) return;
    setProducts(ps => { const exists = ps.find(p => p.id === product.id); return exists ? ps.map(p => p.id===product.id ? product : p) : [...ps, product]; });
    showFlash(`✅ "${product.name}" added — review and save below`);
  }, []);

  const handleEdit = (id, field, val) => setProducts(ps => ps.map(p => p.id===id ? { ...p, [field]: val } : p));

  const saveProduct = async (product) => {
    setSaving(s => ({ ...s, [product.id]: true }));
    try {
      const res = await fetch(`/api/products/${product.id}`, { method:"PATCH", headers:{"Content-Type":"application/json"}, body: JSON.stringify(product) });
      if (!res.ok) throw new Error();
      showFlash(`✅ Saved "${product.name}"`);
    } catch { showFlash("❌ Save failed", "error"); }
    finally { setSaving(s => ({ ...s, [product.id]: false })); }
  };

  const deleteProduct = async (id, name) => {
    if (!confirm(`Delete "${name}"?`)) return;
    await fetch(`/api/products/${id}`, { method:"DELETE" });
    setProducts(ps => ps.filter(p => p.id !== id));
    showFlash(`🗑 Deleted "${name}"`);
  };

  const toggleStock = async (id) => {
    const p = products.find(x => x.id === id);
    const updated = { ...p, in_stock: !p.in_stock };
    setProducts(ps => ps.map(x => x.id===id ? updated : x));
    await fetch(`/api/products/${id}`, { method:"PATCH", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ in_stock: updated.in_stock }) });
  };

  const handleCsvUpload = async (e) => {
    const file = e.target.files?.[0]; if (!file) return;
    try {
      const res  = await fetch("/api/upload", { method:"POST", headers:{"Content-Type":"text/plain"}, body: await file.text() });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setProducts(data.products);
      showFlash(`✅ CSV imported — ${data.products.length} products`);
    } catch (err) { showFlash("❌ " + err.message, "error"); }
    e.target.value = "";
  };

  const downloadCsv = async () => {
    const blob = await fetch("/api/products?format=csv").then(r => r.blob());
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "products.csv"; a.click();
  };

  const needsEdit = products.filter(p => p.price === "EDIT_ME" || !p.price).length;

  return (
    <>
      {flash && <div className={`flash flash-${flash.type}`}>{flash.msg}</div>}
      {/* Stats */}
      <div style={{ display:"flex", gap:".75rem", flexWrap:"wrap", marginBottom:"1.5rem" }}>
        {[["Total",products.length,"#1e1b2e"],["In Stock",products.filter(p=>p.in_stock).length,"#059669"],["Out of Stock",products.filter(p=>!p.in_stock).length,"#dc2626"],["Needs Edit",needsEdit,"#d97706"]].map(([label,value,color]) => (
          <div key={label} style={{ background:"#fff",border:"2px solid #e5e7eb",borderRadius:12,padding:".75rem 1.25rem",textAlign:"center",minWidth:88 }}>
            <div style={{ fontSize:"1.5rem",fontWeight:800,color }}>{value}</div>
            <div style={{ fontSize:".7rem",color:"#6b7280",fontWeight:700 }}>{label}</div>
          </div>
        ))}
      </div>
      {/* Upload */}
      <div className="admin-section">
        <h2>🤖 Add Products via AI Image Scan</h2>
        <p style={{ fontSize:".82rem",color:"#9ca3af",marginBottom:"1rem" }}>Drop any product photo. Claude reads the image and fills in details automatically. Images are auto-compressed to WebP.</p>
        <UploadZone onProductAdded={handleProductAdded} />
      </div>
      {/* CSV */}
      <div className="admin-section">
        <h2>📂 Import / Export CSV</h2>
        <div style={{ display:"flex",gap:".75rem",flexWrap:"wrap" }}>
          <button className="btn btn-outline" onClick={() => fileRef.current.click()}>⬆ Upload CSV</button>
          <button className="btn btn-teal" onClick={downloadCsv}>⬇ Download CSV</button>
          <input ref={fileRef} type="file" accept=".csv" style={{ display:"none" }} onChange={handleCsvUpload} />
        </div>
      </div>
      {/* Table */}
      <div className="admin-section">
        <h2>📦 All Products</h2>
        <div style={{ overflowX:"auto" }}>
          <table className="admin-table">
            <thead><tr><th>Image</th><th>Name</th><th>Price (JMD)</th><th>Code</th><th>Category</th><th>Stock</th><th>Source</th><th>Save</th><th></th></tr></thead>
            <tbody>
              {products.map(p => (
                <tr key={p.id} style={{ opacity: (!p.price || p.price==="EDIT_ME") ? .75 : 1 }}>
                  <td><img src={p.image_path||"/placeholder.png"} alt={p.name} width={52} height={52} style={{ borderRadius:8,objectFit:"cover",background:"#f3f4f6" }} /></td>
                  <td><input className="admin-input" style={{ minWidth:150 }} value={p.name} onChange={e => handleEdit(p.id,"name",e.target.value)} /></td>
                  <td><input className="admin-input" style={{ width:80 }} value={p.price||""} placeholder="0.00" onChange={e => handleEdit(p.id,"price",e.target.value)} /></td>
                  <td><input className="admin-input" style={{ width:90 }} value={p.product_code||""} onChange={e => handleEdit(p.id,"product_code",e.target.value)} /></td>
                  <td><select className="admin-input" style={{ width:140 }} value={p.category} onChange={e => handleEdit(p.id,"category",e.target.value)}>{CATEGORIES.map(c=><option key={c}>{c}</option>)}</select></td>
                  <td style={{ textAlign:"center" }}>
                    <button onClick={() => toggleStock(p.id)} style={{ padding:"3px 10px",borderRadius:8,border:"none",cursor:"pointer",fontWeight:700,fontSize:".75rem",background:p.in_stock?"#d1fae5":"#fee2e2",color:p.in_stock?"#065f46":"#991b1b" }}>{p.in_stock?"✓ In Stock":"✗ OOS"}</button>
                  </td>
                  <td><span className={`tag ${(!p.price||p.price==="EDIT_ME")?"tag-needs-edit":"tag-ok"}`}>{p.source||"—"}</span></td>
                  <td><button className="btn btn-pink btn-sm" onClick={() => saveProduct(p)} disabled={saving[p.id]}>{saving[p.id]?"…":"Save"}</button></td>
                  <td><button onClick={() => deleteProduct(p.id,p.name)} style={{ background:"none",border:"none",cursor:"pointer",color:"#d1d5db",fontSize:"1rem" }} title="Delete">🗑</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
