import "./globals.css";
import { CartProvider } from "@/lib/CartContext";
export const metadata = {
  title: "TiiBaby Shop 🌸",
  description: "Premium baby products in Jamaica — carriers, strollers, accessories & more",
};
export const viewport = { width:"device-width", initialScale:1, maximumScale:1 };
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <CartProvider>{children}</CartProvider>
      </body>
    </html>
  );
}
